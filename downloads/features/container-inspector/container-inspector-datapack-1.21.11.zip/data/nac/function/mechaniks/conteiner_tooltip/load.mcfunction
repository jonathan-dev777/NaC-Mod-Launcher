say NaC Container Inspector loaded
scoreboard objectives add nac_holz dummy
scoreboard objectives add nac_erze dummy
scoreboard objectives add nac_stein dummy
scoreboard objectives add nac_sonstiges dummy
scoreboard objectives add nac_total dummy
scoreboard objectives add nac_best dummy
scoreboard objectives add nac_tmp dummy
scoreboard objectives add nac_hit dummy
scoreboard objectives add nac_ray dummy
scoreboard objectives add nac_ct_enabled dummy
scoreboard objectives add nac_yaw dummy
scoreboard objectives add nac_side dummy

