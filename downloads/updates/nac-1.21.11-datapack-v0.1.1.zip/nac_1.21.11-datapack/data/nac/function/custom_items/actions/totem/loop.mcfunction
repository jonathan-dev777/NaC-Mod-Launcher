execute as @a at @s if entity @s[y= -128,dy = -1000] run function nac:custom_items/actions/totem/activate
say test totem
schedule function nac:custom_items/actions/totem/loop 3t