#Invisibliel Item Frame
#execute as @e[type=minecraft:item_frame,tag=Invisibel] unless data entity @s Item.id run data merge entity @s {Invisible:0b}
#execute as @e[type=minecraft:item_frame,tag=Invisible] if data entity @s item.count run data merge entity @s {Invisible:1b}


#Ladder expand downwards
#execute as @e[type=item,nbt={Item:{id:"minecraft:ladder"}}] at @s if block ~ ~1 ~ ladder if block ~ ~ ~ air run function nac:mechaniks/ladder

execute as @a[scores={nac_ct_enabled=1..}] at @s run function nac:mechaniks/conteiner_tooltip/start
execute as @a unless score @s nac_ct_enabled matches 1.. if items entity @s weapon.mainhand minecraft:paper[minecraft:custom_data~{nac_container_tooltip:true}] at @s run function nac:mechaniks/conteiner_tooltip/start
execute as @a unless score @s nac_ct_enabled matches 1.. if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{nac_container_tooltip:true}] at @s run function nac:mechaniks/conteiner_tooltip/start
