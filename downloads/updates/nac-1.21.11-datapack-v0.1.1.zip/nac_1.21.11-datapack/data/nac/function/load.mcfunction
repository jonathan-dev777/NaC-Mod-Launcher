say NaC v0.1.1 has loaded
function nac:start_up
