scoreboard players set @s nac_hit 1
execute unless items block ~ ~ ~ container.* * run function nac:mechaniks/conteiner_tooltip/clear
execute if items block ~ ~ ~ container.* * align xyz positioned ~0.5 ~ ~0.5 run function nac:mechaniks/conteiner_tooltip/show
