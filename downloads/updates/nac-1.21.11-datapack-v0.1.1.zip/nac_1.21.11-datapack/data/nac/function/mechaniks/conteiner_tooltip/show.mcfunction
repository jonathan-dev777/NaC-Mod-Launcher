# Displays nur einmal erzeugen.
execute unless entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] run summon minecraft:item_display ~ ~1.05 ~ {Tags:["nac_container_item"],item:{id:"minecraft:air",count:1},item_display:"ground",billboard:"fixed",interpolation_duration:0,teleport_duration:0,transformation:{scale:[0.84f,0.84f,0.84f]}}
execute unless entity @e[type=minecraft:text_display,tag=nac_container_custom,limit=1] run summon minecraft:text_display ~ ~2.28 ~ {Tags:["nac_container_custom"],billboard:"center",alignment:"center",background:0,shadow: true,view_range:32.0f,line_width:300,text:{text:""}}
execute unless entity @e[type=minecraft:text_display,tag=nac_container_title,limit=1] run summon minecraft:text_display ~ ~2.00 ~ {Tags:["nac_container_title"],billboard:"center",alignment:"center",background:0,shadow: true,view_range:32.0f,line_width:300,text:{translate:"container.chest",fallback:"Chest"}}
execute unless entity @e[type=minecraft:text_display,tag=nac_container_categories,limit=1] run summon minecraft:text_display ~ ~1.70 ~ {Tags:["nac_container_categories"],billboard:"center",alignment:"center",background:0,shadow: true,view_range:32.0f,line_width:300,text:{text:""}}
execute unless entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] run summon minecraft:text_display ~ ~1.45 ~ {Tags:["nac_container_best"],billboard:"center",alignment:"center",background:0,shadow: true,view_range:32.0f,line_width:300,text:{text:""}}

# Alle Displays exakt auf die Mitte des aktuell geprüften Containers setzen.
# Der Item-Display-Standort wird danach nur für das Fass angepasst.
tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~ ~1.05 ~ 0 0
tp @e[type=minecraft:text_display,tag=nac_container_custom,limit=1] ~ ~2.28 ~
tp @e[type=minecraft:text_display,tag=nac_container_title,limit=1] ~ ~2.00 ~
tp @e[type=minecraft:text_display,tag=nac_container_categories,limit=1] ~ ~1.70 ~
tp @e[type=minecraft:text_display,tag=nac_container_best,limit=1] ~ ~1.45 ~

# Fass: wenn oben kein ersetzbarer Block ist, bleibt das Item oben.
# Wenn oben ein fester Block ist, kommt es auf die feste Seite, in die der Spieler schaut.

# Container-Typ.
execute if block ~ ~ ~ minecraft:barrel run data modify entity @e[type=minecraft:text_display,tag=nac_container_title,limit=1] text set value {translate:"container.barrel",fallback:"Barrel"}
execute if block ~ ~ ~ minecraft:chest run data modify entity @e[type=minecraft:text_display,tag=nac_container_title,limit=1] text set value {translate:"container.chest",fallback:"Chest"}
execute if block ~ ~ ~ minecraft:trapped_chest run data modify entity @e[type=minecraft:text_display,tag=nac_container_title,limit=1] text set value {translate:"container.chest",fallback:"Chest"}

# Eigener Containername: eigene Zeile über dem Container-Typ.
execute if data block ~ ~ ~ CustomName align xyz positioned ~0.5 ~ ~0.5 run data modify entity @e[type=minecraft:text_display,tag=nac_container_custom,limit=1] text set from block ~ ~ ~ CustomName
execute unless data block ~ ~ ~ CustomName run data modify entity @e[type=minecraft:text_display,tag=nac_container_custom,limit=1] text set value {text:""}

function nac:mechaniks/conteiner_tooltip/update
# Fass: oben blockiert -> Seitenposition. Frei -> flach oben.

# Fass: oben frei = flach oben. Oben blockiert = an die dem Spieler zugewandte Seite.
execute if block ~ ~ ~ minecraft:barrel if block ~ ~1 ~ #minecraft:replaceable run function nac:mechaniks/conteiner_tooltip/barrel_top
execute if block ~ ~ ~ minecraft:barrel unless block ~ ~1 ~ #minecraft:replaceable run function nac:mechaniks/conteiner_tooltip/barrel_side

