execute as @a at @s if biome ~ ~ ~ snowy_beach anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ snowy_plains anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ snowy_slopes anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ snowy_taiga anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ frozen_ocean anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ frozen_peaks anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ frozen_river anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
execute as @a at @s if biome ~ ~ ~ deep_frozen_ocean anchored eyes run particle dust{color:[1.000,1.000,1.000],scale:0.5} ^0 ^-0.175 ^0.3 0 0 0 1 0 normal
schedule function nac:mechaniks/cold_air 5s