# Immer zuerst leeren. Dadurch bleibt kein alter Gegenstand stehen, wenn nichts aus der Kandidatenliste passt.
data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:air",count:1}
data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {text:""}
scoreboard players set #best nac_best 0
scoreboard players set #tmp nac_tmp 0
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:oak_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:oak_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.oak_log",fallback:"Oak Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:spruce_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:spruce_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.spruce_log",fallback:"Spruce Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:birch_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:birch_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.birch_log",fallback:"Birch Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:jungle_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:jungle_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.jungle_log",fallback:"Jungle Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:acacia_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:acacia_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.acacia_log",fallback:"Acacia Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:dark_oak_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:dark_oak_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.dark_oak_log",fallback:"Dark Oak Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:mangrove_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:mangrove_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.mangrove_log",fallback:"Mangrove Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:cherry_log[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:cherry_log",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.cherry_log",fallback:"Cherry Log"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:crimson_stem[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:crimson_stem",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.crimson_stem",fallback:"Crimson Stem"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:warped_stem[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:warped_stem",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.warped_stem",fallback:"Warped Stem"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bamboo_block[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bamboo_block",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bamboo_block",fallback:"Bamboo Block"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:oak_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:oak_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.oak_planks",fallback:"Oak Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:spruce_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:spruce_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.spruce_planks",fallback:"Spruce Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:birch_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:birch_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.birch_planks",fallback:"Birch Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:jungle_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:jungle_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.jungle_planks",fallback:"Jungle Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:acacia_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:acacia_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.acacia_planks",fallback:"Acacia Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:dark_oak_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:dark_oak_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.dark_oak_planks",fallback:"Dark Oak Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:mangrove_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:mangrove_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.mangrove_planks",fallback:"Mangrove Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:cherry_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:cherry_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.cherry_planks",fallback:"Cherry Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:crimson_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:crimson_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.crimson_planks",fallback:"Crimson Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:warped_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:warped_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.warped_planks",fallback:"Warped Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bamboo_planks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bamboo_planks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bamboo_planks",fallback:"Bamboo Planks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:stick[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:stick",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.stick",fallback:"Stick"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:coal[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:coal",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.coal",fallback:"Coal"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:charcoal[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:charcoal",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.charcoal",fallback:"Charcoal"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:raw_iron[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:raw_iron",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.raw_iron",fallback:"Raw Iron"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:raw_copper[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:raw_copper",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.raw_copper",fallback:"Raw Copper"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:raw_gold[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:raw_gold",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.raw_gold",fallback:"Raw Gold"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:iron_ingot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:iron_ingot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.iron_ingot",fallback:"Iron Ingot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:copper_ingot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:copper_ingot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.copper_ingot",fallback:"Copper Ingot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:gold_ingot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:gold_ingot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.gold_ingot",fallback:"Gold Ingot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:diamond[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:diamond",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.diamond",fallback:"Diamond"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:emerald[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:emerald",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.emerald",fallback:"Emerald"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:lapis_lazuli[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:lapis_lazuli",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.lapis_lazuli",fallback:"Lapis Lazuli"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:redstone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:redstone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.redstone",fallback:"Redstone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:quartz[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:quartz",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.quartz",fallback:"Quartz"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:netherite_scrap[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:netherite_scrap",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.netherite_scrap",fallback:"Netherite Scrap"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:netherite_ingot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:netherite_ingot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.netherite_ingot",fallback:"Netherite Ingot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:amethyst_shard[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:amethyst_shard",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.amethyst_shard",fallback:"Amethyst Shard"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:ancient_debris[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:ancient_debris",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.ancient_debris",fallback:"Ancient Debris"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:stone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:stone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.stone",fallback:"Stone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:cobblestone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:cobblestone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.cobblestone",fallback:"Cobblestone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:mossy_cobblestone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:mossy_cobblestone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.mossy_cobblestone",fallback:"Mossy Cobblestone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:smooth_stone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:smooth_stone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.smooth_stone",fallback:"Smooth Stone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:stone_bricks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:stone_bricks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.stone_bricks",fallback:"Stone Bricks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:deepslate[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:deepslate",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.deepslate",fallback:"Deepslate"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:cobbled_deepslate[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:cobbled_deepslate",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.cobbled_deepslate",fallback:"Cobbled Deepslate"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:polished_deepslate[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:polished_deepslate",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.polished_deepslate",fallback:"Polished Deepslate"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:granite[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:granite",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.granite",fallback:"Granite"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:diorite[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:diorite",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.diorite",fallback:"Diorite"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:andesite[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:andesite",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.andesite",fallback:"Andesite"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:tuff[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:tuff",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.tuff",fallback:"Tuff"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:calcite[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:calcite",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.calcite",fallback:"Calcite"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:obsidian[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:obsidian",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.obsidian",fallback:"Obsidian"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:sandstone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:sandstone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.sandstone",fallback:"Sandstone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:red_sandstone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:red_sandstone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.red_sandstone",fallback:"Red Sandstone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bricks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bricks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bricks",fallback:"Bricks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:nether_bricks[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:nether_bricks",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.nether_bricks",fallback:"Nether Bricks"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:prismarine[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:prismarine",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.prismarine",fallback:"Prismarine"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:end_stone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:end_stone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.end_stone",fallback:"End Stone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:purpur_block[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:purpur_block",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.purpur_block",fallback:"Purpur Block"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:terracotta[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:terracotta",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.terracotta",fallback:"Terracotta"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:dirt[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:dirt",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.dirt",fallback:"Dirt"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:grass_block[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:grass_block",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.grass_block",fallback:"Grass Block"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:sand[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:sand",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.sand",fallback:"Sand"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:gravel[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:gravel",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.gravel",fallback:"Gravel"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:flint[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:flint",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.flint",fallback:"Flint"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:string[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:string",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.string",fallback:"String"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:feather[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:feather",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.feather",fallback:"Feather"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:leather[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:leather",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.leather",fallback:"Leather"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bone[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bone",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bone",fallback:"Bone"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bone_meal[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bone_meal",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bone_meal",fallback:"Bone Meal"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:gunpowder[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:gunpowder",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.gunpowder",fallback:"Gunpowder"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:paper[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:paper",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.paper",fallback:"Paper"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:book[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:book",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.book",fallback:"Book"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:wheat[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:wheat",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.wheat",fallback:"Wheat"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:wheat_seeds[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:wheat_seeds",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.wheat_seeds",fallback:"Wheat Seeds"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:carrot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:carrot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.carrot",fallback:"Carrot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:potato[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:potato",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.potato",fallback:"Potato"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:beetroot[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:beetroot",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.beetroot",fallback:"Beetroot"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:apple[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:apple",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.apple",fallback:"Apple"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bread[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bread",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bread",fallback:"Bread"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:cookie[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:cookie",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.cookie",fallback:"Cookie"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:pumpkin[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:pumpkin",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.pumpkin",fallback:"Pumpkin"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:melon_slice[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:melon_slice",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.melon_slice",fallback:"Melon Slice"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:sweet_berries[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:sweet_berries",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.sweet_berries",fallback:"Sweet Berries"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:egg[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:egg",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.egg",fallback:"Egg"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:snowball[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:snowball",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.snowball",fallback:"Snowball"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:arrow[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:arrow",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.arrow",fallback:"Arrow"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:torch[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:torch",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.torch",fallback:"Torch"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:lantern[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:lantern",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.lantern",fallback:"Lantern"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:bucket[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:bucket",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.bucket",fallback:"Bucket"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:glass[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:glass",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.glass",fallback:"Glass"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:iron_nugget[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:iron_nugget",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.iron_nugget",fallback:"Iron Nugget"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:gold_nugget[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:gold_nugget",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.gold_nugget",fallback:"Gold Nugget"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:slime_ball[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:slime_ball",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.slime_ball",fallback:"Slime Ball"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:ender_pearl[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:ender_pearl",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.ender_pearl",fallback:"Ender Pearl"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:blaze_rod[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:blaze_rod",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.blaze_rod",fallback:"Blaze Rod"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:magma_cream[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:magma_cream",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.magma_cream",fallback:"Magma Cream"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp
execute store result score #tmp nac_tmp if items block ~ ~ ~ container.* minecraft:nether_wart[minecraft:count~{min:1}]
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:nether_wart",count:1}
execute if score #tmp nac_tmp > #best nac_best run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {translate:"item.minecraft.nether_wart",fallback:"Nether Wart"}
execute if score #tmp nac_tmp > #best nac_best run scoreboard players operation #best nac_best = #tmp nac_tmp

# Falls kein bekannter Kandidat vorhanden ist, bleibt die Anzeige leer.
execute if score #best nac_best matches 0 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item set value {id:"minecraft:air",count:1}
execute if score #best nac_best matches 0 run data modify entity @e[type=minecraft:text_display,tag=nac_container_best,limit=1] text set value {text:""}
