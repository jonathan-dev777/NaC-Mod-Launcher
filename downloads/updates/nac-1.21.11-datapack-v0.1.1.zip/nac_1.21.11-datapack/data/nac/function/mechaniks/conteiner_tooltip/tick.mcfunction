execute as @a[scores={nac_ct_enabled=1..}] at @s run function nac:mechaniks/conteiner_tooltip/start
execute as @a unless score @s nac_ct_enabled matches 1.. if items entity @s weapon.mainhand minecraft:paper[minecraft:custom_data~{nac_container_tooltip:true}] at @s run function nac:mechaniks/conteiner_tooltip/start
execute as @a unless score @s nac_ct_enabled matches 1.. if items entity @s weapon.offhand minecraft:paper[minecraft:custom_data~{nac_container_tooltip:true}] at @s run function nac:mechaniks/conteiner_tooltip/start
