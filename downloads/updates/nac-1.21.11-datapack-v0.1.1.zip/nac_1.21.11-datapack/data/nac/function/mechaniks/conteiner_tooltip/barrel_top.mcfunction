data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "ground"
data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {left_rotation:[-0.70090926f,0.0f,0.0f,0.71325046f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.84f,0.84f,0.84f],translation:[0.0f,0.0f,0.0f]}
tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~ ~1.02 ~ 0 0
