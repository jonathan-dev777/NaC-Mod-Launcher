execute if score @s nac_yaw matches -45..45 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "fixed"
execute if score @s nac_yaw matches -45..45 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.60f,0.60f,0.60f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}
execute if score @s nac_yaw matches -45..45 run tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~ ~0.50 ~-0.505 180 0

execute if score @s nac_yaw matches 46..135 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "fixed"
execute if score @s nac_yaw matches 46..135 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.60f,0.60f,0.60f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}
execute if score @s nac_yaw matches 46..135 run tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~0.505 ~0.50 ~-0.0 270 0

execute if score @s nac_yaw matches -135..-46 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "fixed"
execute if score @s nac_yaw matches -135..-46 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.60f,0.60f,0.60f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}
execute if score @s nac_yaw matches -135..-46 run tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~-0.505 ~0.50 ~0.0 90 0

execute if score @s nac_yaw matches 136..180 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "fixed"
execute if score @s nac_yaw matches 136..180 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.60f,0.60f,0.60f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}
execute if score @s nac_yaw matches 136..180 run tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~ ~0.50 ~0.505 0 0

execute if score @s nac_yaw matches -180..-136 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] item_display set value "fixed"
execute if score @s nac_yaw matches -180..-136 run data modify entity @e[type=minecraft:item_display,tag=nac_container_item,limit=1] transformation set value {translation:[0.0f,0.0f,0.0f],left_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.60f,0.60f,0.60f],right_rotation:[0.0f,0.0f,0.0f,1.0f]}
execute if score @s nac_yaw matches -180..-136 run tp @e[type=minecraft:item_display,tag=nac_container_item,limit=1] ~ ~0.50 ~0.505 0 0
