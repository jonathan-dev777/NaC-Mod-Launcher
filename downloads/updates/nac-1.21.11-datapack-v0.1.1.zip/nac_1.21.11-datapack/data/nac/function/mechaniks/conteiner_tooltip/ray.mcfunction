execute if block ~ ~ ~ minecraft:chest run function nac:mechaniks/conteiner_tooltip/inspect
execute if block ~ ~ ~ minecraft:trapped_chest run function nac:mechaniks/conteiner_tooltip/inspect
execute if block ~ ~ ~ minecraft:barrel run function nac:mechaniks/conteiner_tooltip/inspect
execute if score @s nac_hit matches 0 if score @s nac_ray matches 1.. run scoreboard players remove @s nac_ray 1
execute if score @s nac_hit matches 0 if score @s nac_ray matches 1.. positioned ^ ^ ^0.25 run function nac:mechaniks/conteiner_tooltip/ray
