# Anzahl aller Items im Container
execute store result score #total nac_total if items block ~ ~ ~ container.* *

# Kategorien: execute if items liefert die Gesamtanzahl der passenden Items.
execute store result score #holz nac_holz if items block ~ ~ ~ container.* #minecraft:holz
execute store result score #erze nac_erze if items block ~ ~ ~ container.* #minecraft:erze
execute store result score #stein nac_stein if items block ~ ~ ~ container.* #minecraft:stein

# Sonstiges = alles - Holz - Erze - Stein
scoreboard players operation #sonstiges nac_sonstiges = #total nac_total
scoreboard players operation #sonstiges nac_sonstiges -= #holz nac_holz
scoreboard players operation #sonstiges nac_sonstiges -= #erze nac_erze
scoreboard players operation #sonstiges nac_sonstiges -= #stein nac_stein
execute if score #sonstiges nac_sonstiges matches ..-1 run scoreboard players set #sonstiges nac_sonstiges 0

function nac:mechaniks/conteiner_tooltip/update_categories
function nac:mechaniks/conteiner_tooltip/update_best
