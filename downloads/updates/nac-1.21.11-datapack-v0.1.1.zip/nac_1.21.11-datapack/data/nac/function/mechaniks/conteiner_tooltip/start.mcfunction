scoreboard players set @s nac_hit 0
scoreboard players set @s nac_ray 64
execute store result score @s nac_yaw run data get entity @s Rotation[0] 1
execute anchored eyes positioned ^ ^ ^0.1 run function nac:mechaniks/conteiner_tooltip/ray
execute if score @s nac_hit matches 0 run function nac:mechaniks/conteiner_tooltip/clear
