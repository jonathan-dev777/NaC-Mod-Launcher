function nac:custom_items/actions/effects/armor/leather/pants/fest_hose_des_volkes-hero_of_the_village
function nac:maschines/wapons/katapult/katapult_loop
function nac:custom_items/checks