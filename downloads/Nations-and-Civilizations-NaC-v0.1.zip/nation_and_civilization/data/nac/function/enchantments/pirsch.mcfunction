#Sheep
execute if entity @s[type=sheep] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2
execute if entity @s[type=sheep] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2
execute if entity @s[type=sheep] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3
execute if entity @s[type=sheep] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3
execute if entity @s[type=sheep] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4
say hi
#Pig
execute if entity @s[type=pig] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2
execute if entity @s[type=pig] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2
execute if entity @s[type=pig] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3
execute if entity @s[type=pig] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3
execute if entity @s[type=pig] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4

#Chicken
execute if entity @s[type=chicken] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=chicken] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=chicken] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=chicken] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=chicken] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4 minecraft:player_attack

#Cow
execute if entity @s[type=cow] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=cow] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=cow] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=cow] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=cow] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4 minecraft:player_attack

#Horse
execute if entity @s[type=horse] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=horse] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=horse] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=horse] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=horse] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4 minecraft:player_attack

#Donkey
execute if entity @s[type=donkey] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":1}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=donkey] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":2}}}}] run damage @s 2 minecraft:player_attack
execute if entity @s[type=donkey] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":3}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=donkey] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":4}}}}] run damage @s 3 minecraft:player_attack
execute if entity @s[type=donkey] if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:pirsch":5}}}}] run damage @s 4 minecraft:player_attack