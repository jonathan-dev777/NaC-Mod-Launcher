execute if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:poisoning":1}}}}] run effect give @s poison 4
execute if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:poisoning":2}}}}] run effect give @s poison 6
execute if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:poisoning":3}}}}] run effect give @s poison 8
execute if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:poisoning":4}}}}] run effect give @s poison 10
execute if entity @p[distance=0..5,nbt={SelectedItem:{components:{"minecraft:enchantments":{"nac:poisoning":5}}}}] run effect give @s poison 12