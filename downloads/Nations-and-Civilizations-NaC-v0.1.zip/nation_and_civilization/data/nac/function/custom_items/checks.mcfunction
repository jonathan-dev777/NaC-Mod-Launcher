execute as @e[type=minecraft:item_frame,tag=Invisibel] unless data entity @s Item.id run data merge entity @s {Invisible:0b}
execute as @e[type=minecraft:item_frame,tag=Invisible] if data entity @s Item.id run data merge entity @s {Invisible:1b}
function nac:custom_items/checks