say NaC has loaded
function nac:start_up