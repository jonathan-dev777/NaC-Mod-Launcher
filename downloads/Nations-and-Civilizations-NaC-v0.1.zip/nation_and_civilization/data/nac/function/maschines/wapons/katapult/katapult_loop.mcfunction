function nac:maschines/wapons/katapult/checks/armorstand_in_boat
function nac:maschines/wapons/katapult/checks/armorstand_on_boat
function nac:maschines/wapons/katapult/checks/water_check
function nac:maschines/wapons/katapult/checks/only_player_move
function nac:maschines/wapons/katapult/attack/load
schedule function nac:maschines/wapons/katapult/katapult_loop 0.2s