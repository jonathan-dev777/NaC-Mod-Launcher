schedule clear nac:maschines/wapons/katapult/katapult_loop
schedule clear nac:custom_items/checks