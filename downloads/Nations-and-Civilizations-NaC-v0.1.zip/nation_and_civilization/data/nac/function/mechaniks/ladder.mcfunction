clone ~ ~1 ~ ~ ~1 ~ ~ ~ ~
execute if data entity @s {Item:{count: 1}} run kill @s
execute if data entity @s {Item: {count: 2..}} store result entity @s Item.count byte -1 run data get entity @s Item.count